document.querySelector('#btn').addEventListener('click', () => {
  alert('JS работает!');
});
document.querySelector('#ts span').textContent = new Date().toISOString();
